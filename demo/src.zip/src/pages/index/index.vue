<template>
	<div>
		<div class="search">
			<div class="search_box">
				<van-search placeholder="请输入搜索关键词" v-model="value" input-align="center" @focus="goSearch"/>
			</div>
			<div class="speak">
				<img src="../../../static/images/cs.png" alt="" @click="goService">
			</div>
		</div>
		<div class="contain">
			<scroll-view scroll-y>
				<div class="banner" v-if="getContentPageDataList">
					<swiper :images="getContentPageDataList"></swiper>
					<!-- <swiper class="swiper">
						<block v-for="(item, index) in getContentPageDataList" :key="index">
							<swiper-item>
								<image :src="item.img" @click="imgSearch" class="slide-image" mode="aspectFill" />
							</swiper-item>
						</block>
					</swiper> -->
				</div>
				<ul class="nav" v-if="getContentPageNavList">
					<li v-for="(item, i) in getContentPageNavList" :key="i" @click="imgSearch(item)">
						<img :src="item.img" alt="">
						<span>{{item.title}}</span>
					</li>
				</ul>
				<ul class="nav-list" v-if="getContentPageImgList">
					<li v-for="(item, i) in getContentPageImgList" :key="i" @click="imgClick(item)">
						<img :src="item.img" alt="">
					</li>
				</ul>
				<div class="block-d">
					<div class="list-header" v-if="getCartTitle">
						<img src="../../../static/images/divider.png" alt="">
						<span>{{getCartTitle}}</span>
						<img src="../../../static/images/divider.png" alt="">
					</div>

					<div class="banner" v-if="getContentPageCartList">
						<swiper :images="getContentPageCartList"></swiper>
					</div>
					<ul class="cart-list" v-if="getContentPageProductList">
						<li v-for="(item, i) in getContentPageProductList" :key="i">
							<img :src="item.photos[0].image" alt="">
							<span>{{item.name}}</span>
							<span class="list_price">AUD${{item.price}}</span>
						</li>
					</ul>
				</div>
				<div class="block-e">
					<div class="list-header" v-if="getCartETitle">
						<img src="../../../static/images/divider.png" alt="">
						<span>{{getCartETitle}}</span>
						<img src="../../../static/images/divider.png" alt="">
					</div>

					<div class="banner" v-if="getContentPageProductImg">
						<swiper :images="getContentPageProductImg"></swiper>
					</div>
					<ul class="e-list">
						<li v-for="(item, i) in cmsProductList" :key="i">
							<div class="line"></div>
							<div class="e-product">
								<img :src="item.photos[0].image" alt="">
								<div class="e-content">
									<div class="e-title">{{item.name}}</div>
									<div class="e-price">
										<span class="e-left">UAD${{item.price}}</span>
										<span class="e-right">（约合¥{{item.currency_price}}）</span>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</scroll-view>
		</div>
	</div>
</template>

<script>
	import Swiper from "@/components/swiper"
	import Category from '@lib/pagination/Category'
	import Home from '@lib/pagination/CmsProduct'
	import searchLib from '@lib/search'
	import Utli from '@lib/Utli'
	export default {
		data() {
			return {
				value: '',
				images: [{
						url: "../../static/images/banner2.jpg"
					},
					{
						url: "../../static/images/banner3.jpg"
					}
				],
				timer: null,
				getContentPageDataList: null,
				getContentPageNavList: null,
				getContentPageImgList: null,
				getContentPageCartList: null,
				getCartTitle: null,
				getContentPageProductList: null,
				getCartETitle: null,
				cmsProductList: null
			}
		},
		beforeUpdate() {
			this.getContentPageDataList = this.getContentPageData.data.block_a.data
			this.getContentPageNavList = this.getContentPageData.data.block_b.data
			this.getContentPageImgList = this.getContentPageData.data.block_c.data
			this.getCartTitle = this.getContentPageData.data.block_d.title
			this.getCartETitle = this.getContentPageData.data.block_e.title
			this.getContentPageCartList = this.getContentPageData.data.block_d.data
			this.getContentPageProductList = this.getContentPageData.data.category_products[0].products
			this.getContentPageProductImg = this.getContentPageData.data.block_e.data
			this.cmsProductList = this.homepageProductData.data
			console.log(this.getContentPageImgList,'查询点击事件')
		},
		mounted() {
			this.init()
			console.log('开始测试')
			this.$router.log('你好啊')
		},
		computed: {
			getContentPageData() {
				return this.$store.getters['page/getContentPageData']
			},
			homepageProductData() {
				return this.$store.getters['product/allProducts']
			}
		},
		methods: {
			init() {
				// this.$store.commit('product/SET_DATA_TO_LOC', [])
				Category.init({
					store: this.$store
				})
				Category.loadInitData({
					timeout: 100,
					needConcat: false,
					forceLoad: true
				})
				let pages = getCurrentPages()
				let currentPage = pages[pages.length - 1]
				let url = currentPage.route
				console.log(url + '我是首页的路径')
				// let id = (url === 'pages/index/contentPage') ? currentPage.options.content_page : null
				let id = null
				Home.init({
					store: this.$store,
					id
				})
				// setTimeout(() => {
				// 		this.timer = LoadingApi.start()
				// }, 0)
				this.loadHomeCategoryProduct(() => {
					Home.loadInitData({
						timeout: 200,
						needConcat: false,
						forceLoad: true,
						cb: (r) => {
							LoadingApi.destroy(this.timer)
						}
					})
				})
			},
			loadHomeCategoryProduct(cb) {
				let request = `?size=100&currency=CNY&has_photo=true&is_base64=false&type=homepage&device=mobile`
				this.$store.dispatch('page/GET_CONTENT_PAGE_DATA_FROM_CLOUD', {
					request,
					cb
				})
			},
			refreshHome(cb) {
				console.log('下拉刷新了')
				this.loadHomeCategoryProduct(function() {
					Home.refresh(cb)
				})
			},
			moreHome(cb) {
				Home.more(cb)
			},
			bannerClick(item) {
				console.log(item)
				if (item.link.type === 'keyword') {
					this.goToSearch(item.link.value)
				} else {
					this.goToTarget(item.link.value)
				}
			},
			imgSearch(item) {
				console.log(item,111111)
				if (item.link.type === 'keyword') {
					this.goToSearch(item.link.value)
				} else {
					this.goToTarget(item.link.value)
				}
			},
			goToSearch(keyword) {
				var that = this
				searchLib.findResultByKeyword(this.$store, this.$router, keyword, function() {}, 1)
				setTimeout(function(){
					that.$router.push('../search/main')
				},2000)
			},
			goToTarget(url, i) {
				console.log(url);
				let patten = /product|category|home|service|cms/ig
				if (!patten.test(url)) {
					Utli.goToUrlWithAuth(this.$store, this.$router, {
						url
					}, 'push')
				} else {
					Utli.goToUrl(this.$router, {
						url
					}, 'push')
				}
			},
			goSearch() {
				this.$router.push('../search/main')
			},
			goService() {
				this.$router.push('../customerService/main')
			},
			imgClick (item) {
				console.log(item)
			  if (item.link.type === 'keyword') {
				console.log('图片第一步')
			    this.goToSearch(item.link.value)
			  } else {
				  console.log('图片第二步')
			    this.goToTarget(item.link.value)
				}
				
			}
		},
		async onPullDownRefresh() {
			this.refreshHome()
		},
		onReachBottom() {
			this.moreHome()
			console.log('上拉加载')
		},
		components: {
			Swiper
		}
	}
</script>

<style>
	.contain {
		width: 100%;
		height: 100%;
	}

	.search {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10px;
		box-sizing: border-box;
		position: fixed;
		z-index: 10;
		background: #fff;
		top: 0;
		left: 0;
	}

	.search_box {
		width: 86%;
	}

	.van-search {
		background: #fff !important;
		border: 3px solid #eee;
		border-radius: 8px;
		padding: 3px !important;
	}

	.speak {
		flex: 1;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.speak img {
		width: 32px;
		height: 32px;
	}

	scroll-view {
		padding-top: 56px;
	}

	.banner {
		width: 100%;
		height: 386rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		padding: 0 10px 10px;
		box-sizing: border-box;
		border-radius: 8px;
		overflow: hidden;
	}

	.swiper {
		height: 376rpx;
	}

	.nav {
		width: 100%;
		display: flex;
		padding: 18px 10px;
		box-sizing: border-box;
		justify-content: space-around;
		align-items: center;
	}

	.nav li {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.nav li img {
		width: 32px;
		height: 32px;
	}

	.nav li span {
		font-size: 28rpx;
		color: #333;
		margin: 18px 0 10px;
	}

	.nav-list {
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		padding: 0 10px;
		box-sizing: border-box;
	}

	.nav-list li {
		width: 49.5%;
		height: 212rpx;
		border-radius: 4px;
		overflow: hidden;
		margin-bottom: 1%;
	}

	.nav-list li img {
		width: 100%;
		height: 100%;
	}

	.block-d {
		width: 100%;
		display: flex;
		flex-direction: column;
		padding: 0 10px;
		box-sizing: border-box;
		margin-top: 20px;
	}

	.list-header {
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-bottom: 20px;
	}

	.list-header img {
		width: 120rpx;
		height: 24rpx;
	}

	.list-header span {
		font-size: 32rpx;
		color: #333;
		margin: 0 20rpx;
	}

	.cart-list {
		width: 100%;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}

	.cart-list li {
		background: rgb(248, 248, 248);
		width: 33.3%;
		display: flex;
		padding: 12rpx;
		box-sizing: border-box;
		flex-direction: column;
	}

	.cart-list li img {
		width: 100%;
		height: 206rpx;
	}

	.cart-list li span {
		font-size: 28rpx;
		color: #333;
		margin: 8px 0;
	}

	.cart-list li .list_price {
		font-size: 36rpx;
		color: red;
		margin: 0;
	}

	.block-e {
		width: 100%;
		display: flex;
		flex-direction: column;
		margin-top: 20px;
	}

	.e-list {
		width: 100%;
		display: flex;
		flex-direction: column;
	}

	.e-list li {
		width: 100%;
		display: flex;
		flex-direction: column;
	}

	.line {
		width: 100%;
		height: 32rpx;
		background: rgb(247, 247, 247);
		padding: 0 10px;
		box-sizing: border-box;
	}

	.e-product {
		width: 100%;
		padding: 16rpx 32rpx;
		box-sizing: border-box;
		display: flex;
	}

	.e-product img {
		width: 130rpx;
		height: 180rpx;
	}

	.e-content {
		flex: 1;
		height: 180rpx;
		padding-left: 32rpx;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.e-title {
		width: 100%;
		color: #333;
		font-size: 32rpx;
	}

	.e-price {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.e-left {
		font-size: 32rpx;
		color: red;
	}

	.e-right {
		font-size: 28rpx;
		color: #333;
	}
</style>

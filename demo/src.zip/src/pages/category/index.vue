<template>
	<div class="contain">
		<div class="search">
			<div class="search_box">
				<van-search placeholder="请输入搜索关键词" v-model="value" input-align="center" />
			</div>
			<div class="speak">
				<img src="../../../static/images/cs.png" alt="">
			</div>
		</div>
		<div class="list">
			<scroll-view scroll-y="true">
				<ul>
					<li @click="choose_category(-1,'all','全部')">
						<p>全部</p>
					</li>
					<li v-for="(item, i) in sliderList" :key="i" @click="choose_category(i,item.uuid,item.name)">
						<p>{{item.name}}</p>
					</li>
				</ul>
			</scroll-view>
			<div class="list_box">
				<div class="banner">
					<swiper :images="bannerList" :indicatorDots="indicatorDots"></swiper>
				</div>
				<divider :text="selectCategoryName"></divider>
				<scroll-view scroll-y="true" style="width:100%;height: 660rpx;" @scrolltolower="moreProduct">
					<div class="product">
						<block v-for="(item, i) in productList" :key="i">
							<div class="content" @click="goDetail(item.uuid)">
								<img :src="item.photos[0].image" alt="">
								<div class="detail">
									<span class="title">{{item.name}}</span>
									<span class="price">AUD${{item.price}}</span>
									<span class="currency">（约合¥{{item.currency_price}}）</span>
								</div>
							</div>
						</block>
					</div>
				</scroll-view>
			</div>
		</div>
	</div>
</template>

<script>
	import Swiper from "@/components/swiper"
	import Divider from "@/components/divider"
	import Category from '@lib/pagination/Category'
	import Product from '@lib/pagination/Product'
	import _ from 'underscore'
	import Utli from '@lib//Utli'

	export default {
		data() {
			return {
				images: [{
						img: "../../static/images/banner2.jpg"
					},
					{
						img: "../../static/images/banner3.jpg"
					}
				],
				text: '全部',
				indicatorDots: false,
				key: -1,
				currentCategory: '',
				activeKey: null,
				type: 'product_category_all',
				selectCategoryName: '全部',
				needResetProduct: false,
				sliderList: null,
				productList: null
			}
		},
		beforeUpdate() {
			this.sliderList = this.categories.data
			this.productList = this.showProductList.data
		},
		mounted() {
			const pages = getCurrentPages()
			const currentPage = pages[pages.length - 1]
			let query = currentPage.options
			let id = query.cid
			console.log(id, 'mounted初始化的页面数据')
			var self = this
			this.$store.commit('category/SET_DATA_TO_LOC', [])
			Category.init({
				store: this.$store
			})
			Category.loadInitData({
				timeout: 100,
				needConcat: false,
				forceLoad: true,
				cb: function(response) {
					let result = self.findCategory(response.data)
					if (result.key >= 0) {
						self.key = parseInt(result.key)
					}
					self.activeCategory(result.key, result.uuid, result.name)
				}
			})
			// changeProductByCategoryUUID('all')
		},
		components: {
			Swiper,
			Divider
		},
		computed: {
			categories() {
				return this.$store.getters['category/allCategory']
			},
			showProductList() {
				return this.$store.getters['product/allProducts']
			},
			bannerList() {
				let src
				if (this.key === -1) {
					src = '../../static/images/homeBanner.png'
				} else {
					src = this.categories.data[this.key].banner_img
				}
				if (!src) {
					src = '../../static/images/homeBanner.png'
				}
				console.log(7777777, 'src: ', src)
				return [{
					url: 'javascript:',
					img: src,
					title: ''
				}]
			}
		},
		methods: {
			findCategory(categories) {
				let result = {
					status: false
				}
				//小程序获取当前页面的路径以及参数
				const pages = getCurrentPages()
				const currentPage = pages[pages.length - 1]
				let query = currentPage.options
				let id = query.cid
				console.log(id, '这里是获取的id')

				if (id !== 'all' && id !== undefined) {
					result.status = true
					if (id !== undefined && id !== this.currentCategory) {
						const findKey = _.findKey(categories, item => item.uuid === id)
						if (findKey !== undefined) {
							this.currentCategory = id
							result.key = findKey
							result.uuid = id
							result.name = categories[findKey].name
						}
					}
				} else {
					result.key = -1
					result.uuid = 'all'
					result.name = '全部'
				}
				console.log(result,'看看result的数据')
				return result
			},
			activeCategory(key, uuid, name) {
				console.log(key,uuid,name,'这是数据')
				this.activeKey = parseInt(key) + 1
				if (uuid !== 'all' && uuid !== undefined) {
					this.type = 'cat_' + uuid
				} else {
					this.type = 'product_category_all'
				}
				this.selectCategoryName = name
				this.currentCategory = uuid
			},
			goDetail(uuid) {
				this.$router.push({path:'../productDetail/main',query:{uuid: uuid}})
			},
			choose_category(key, uuid, name) {
				this.text = name
				this.key = key
				// 				Toast.loading({
				// 					duration: 10000,       
				// 					forbidClick: true,
				// 					loadingType: 'spinner',
				// 					message: this.$t('加载中'),
				// 					mask: true
				// 				})
				// Utli.goToUrl(this.$router, {url: '../category/main',query: {cid: uuid}}, 'push')
				this.changeProductByCategoryUUID(uuid)
				this.activeCategory(key, uuid, name)
			},
			changeProductByCategoryUUID(uuid) {
				var that = this
				that.$store.commit('product/SET_DATA_TO_LOC', [])
				let request = {
					store: that.$store,
					type: that.type
				}
				if (uuid !== 'all' && uuid !== undefined) {
					request.category = uuid
				}
				Product.init(request)
				Product.loadInitData({
					timeout: 100,
					needConcat: false,
					forceLoad: true,
					cb: function() {
						setTimeout(function(){
							that.productList = that.showProductList.data
							console.log(that.productList, '检查是否改变了')
						},800)
						// Toast.clear()
					}
				})
			},
			moreProduct (cb) {
			   console.log('到达底部了')
			   Product.more(cb)
			}
		}
	}
</script>

<style scoped>
	page {
		height: 100vh;
		overflow: hidden;
	}

	.contain {
		height: 100vh;
	}

	.search {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10px;
		box-sizing: border-box;
		position: fixed;
		z-index: 10;
		background: #fff;
		top: 0;
		left: 0;
	}

	.search_box {
		width: 86%;
	}

	.van-search {
		background: #fff !important;
		border: 3px solid #eee;
		border-radius: 8px;
		padding: 3px !important;
	}

	.speak {
		flex: 1;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.speak img {
		width: 32px;
		height: 32px;
	}

	.list {
		width: 100%;
		display: flex;
		padding-top: 56px;
		box-sizing: border-box;
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
	}

	scroll-view {
		width: 184rpx;
	}

	scroll-view ul {
		width: 184rpx;
		display: flex;
		flex-direction: column;
		background: rgb(248, 248, 248);
	}

	scroll-view ul li {
		width: 184rpx;
		height: 116rpx;
		text-align: left;
		font-size: 30rpx;
		color: #333;
		border-bottom: 1px solid #eee;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	scroll-view ul li p {
		text-align: center;
	}

	.list_box {
		width: 78%;
		padding: 16rpx 40rpx;
		background: rgb(251, 249, 254);
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
	}

	.banner {
		width: 100%;
		height: 200rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.product {
		width: 100%;
		display: flex;
		flex-wrap: wrap;
	}

	.content {
		width: 47%;
		display: flex;
		flex-direction: column;
		margin-bottom: 2%;
		border-bottom: 1px solid #eee;
		padding-right: 3%;
		padding-bottom: 2%;
	}

	.content>img {
		width: 100%;
		height: 200rpx;
	}

	.detail {
		width: 100%;
		display: flex;
		flex-direction: column;
		margin-top: 12rpx;
	}

	.title,
	.des {
		font-size: 26rpx;
		color: #333;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap
	}

	.price {
		font-size: 30rpx;
		color: red;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap
	}

	.currency {
		font-size: 24rpx;
		color: #999;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap
	}
</style>

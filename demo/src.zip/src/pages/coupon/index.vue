<template>
  <div id="coupon">
    <div class="title">可用优惠券(<span>{{juan}}</span>)</div>
    <div class="couponList">
      <ul>
        <li>
          <div class="listLeft">
            <h2>仅限奶粉使用</h2>
            <p>无使用门槛</p>
          </div>
          <div class="listRight">
            <h3>20元优惠券</h3>
            <p>有效期：2018.09.14-2018.10.14</p>
          </div>
        </li>
        <li>
          <div class="listLeft">
            <h2>仅限服饰类商品使用</h2>
            <p>限定Mom&Baby类</p>
          </div>
          <div class="listRight">
            <h3>20元优惠券</h3>
            <p>有效期：2018.09.14-2018.10.14</p>
          </div>
        </li>
        
      </ul>
    </div>
  </div>
</template>

<script>

export default {
  data () {
    return{
      juan:2
    }
  }
}
</script>

<style lang='scss'>
#coupon {
  width: 100%;
  height: 100vh;
  overflow-y: auto;
  background: #F8F8F8;
  .title {
    position: fixed;
    width: 100%;
    height: 44px;
    text-align: center;
    font-size: 16px;
    line-height: 44px;
    border-bottom: 2px solid #FF4444;
    margin-bottom: 20px;
    background: #FFFFFF;
    color: #FF4444;
  }
  .couponList {
    width: 100%;
    margin-top: 60px;

    ul{
      li {
        width: 92%;
        margin: 0 auto;
        height: 100px;
        box-shadow: 0 0 4px rgba(0,0,0,.1);
        margin-top: 20px;
        background: #FFFFFF;
        border-radius: 8px;
        .listLeft{
          width: 40%;
          padding: 15px 0 0 10px;
          float: left;
          h2{
            color: #FF4444;
            width: 100%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 600;
          }
          p {
            padding-top: 8px;
            font-size: 12px;
            color: #7e7b7b;
          }
        }
        .listRight{
          width: 52%;
          padding: 15px 10px 0 0;
          float: right;
          h3{
            width: 100%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 500;
          }
          p {
            padding-top: 8px;
            font-size: 12px;
            color: #7e7b7b;
          }
        }
      }
    }
  }
}
</style>

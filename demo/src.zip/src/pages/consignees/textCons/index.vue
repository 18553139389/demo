<template>
  <div class="textCons">
    <van-cell-group>
      <van-field label="收货人" v-model="Consignee" clearable placeholder="姓名"/>
      <van-field label="联系电话" v-model="Phone" clearable placeholder="手机或固定电话"/>
      <van-field label="收件地区" v-model="Phone" clearable placeholder="收件地区"/>
      <van-field label="详细地址" v-model="Phone" clearable placeholder="如街道、楼层、门牌号等"/>
      <van-field label="邮政编码" v-model="Phone" clearable placeholder="选填"/>
      <van-field label="身份证号码" v-model="Phone" clearable placeholder="请输入身份证号码"/>
    </van-cell-group>
    <div class="photo">
      
      <mp-uploader
       @upLoadSuccess="upLoadSuccess" 
       @upLoadFail="upLoadFail" 
       @uploadDelete="uploadDelete" 
       :showTip=false 
       count=2
       maxLength=2
       ></mp-uploader>
      <div class="tips"><span>身份证正面照</span><span>身份证反面照</span></div>
    </div>
    <van-notice-bar mode="closeable" text="根据中国海关要求，请上传身份证正反面，且图片清晰、完整、并在有效期内，此身份证照片仅限海关清关使用。"/>
    <div class="btn" v-if="titNum == 1">
      <button>保存</button>
      <button>删除</button>
    </div>
    <div class="btn" v-else>
      <div class="moren"><span>设为默认收货地址</span> <mp-switch v-model="switchValue" @change="switchChange"></mp-switch></div>
      <button>保存</button>
      
    </div>
  </div>
</template>
<script>
import mpButton from 'mpvue-weui/src/button';
import mpSwitch from 'mpvue-weui/src/switch';
import mpUploader from 'mpvue-weui/src/uploader';
export default {
  data() {
    return {
      tit: "",
      titNum: 0,
      checked: true,
      zmImage: '',
      bmImage: ''
    };
  },
  components:{
    mpButton,
    mpUploader,
    mpSwitch
  },
  onLoad(option) {
    console.log(option);
    let _this = this;
    if (option.id == 1) {
      (_this.tit = "编辑收件人信息"), (_this.titNum = 1);
    } else {
      _this.tit = "新增收件人";
    }
    console.log(_this.tit);
    wx.setNavigationBarTitle({
      title: _this.tit
    });
  }
};
</script>
<style lang="scss">
.photo {
  margin-top: 30rpx;
  width: 100%;
  height: 220rpx;
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-direction: column;
  .tips{
    width: 100%;
    height: 50rpx;
    font-size: 28rpx;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  .weui-uploader{
    width: 69%;
    text-align: center;
    
  }
  
}
.btn {
  margin-top: 20rpx;
  // 默认地址
  .moren{
    width: 96%;
    height: 100rpx;
    margin: 0 auto;
    font-size: 30rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #F3F3F3;
    ._switch{
      width: 100rpx;
      height: 50rpx;
      font-size: 20rpx;
    }
  }
  button{
      margin: 0 auto;
      width: 80%;
      height: 88rpx;
      border: 1px solid #4b0;
      background: #648561 !important;
      color: #fff;
      font-size: 28rpx;
      line-height: 88rpx;
      margin-top: 40rpx;
    }
 
  
}
</style>

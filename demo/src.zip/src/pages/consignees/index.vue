<template>
  <div id="consignees">
    <div class="conList">
    	<ul class="ul">
    		<li class="lis">
    			<input type="radio" name="adress" class="ipt"/>
    			<div class="radioRight">
    				<span>谢谢，</span><span>10086</span>
          	<p>收货地址：<span>上都世贸大厦</span></p>
    			</div>
    			<div class="bianji" @click="taps">
    				<van-icon name="edit" />
    			</div>
    		</li>
    		<li class="lis">
    			<input type="radio" name="adress" class="ipt"/>
    			<div class="radioRight">
    				<span>sandy，</span><span>10086</span>
          	<p>收货地址：<span>商都世贸大厦 商都世贸大厦 商都世贸大厦</span></p>
    			</div>
    			<div class="bianji"  @click="taps">
    				<van-icon name="edit" />
    			</div>
    		</li>
    	</ul>
    </div>
  	<button class="addNew" @click="add">新增地址</button>
  </div>
</template>

<script>

export default {
  data() {
    return {
      radio: '1'
    }
  },
	methods: {
		taps(){
			wx.navigateTo({
				url: "textCons/main?id=1"
			})
			console.log("点击-编辑")
		},
		add(){
			wx.navigateTo({
				url: "textCons/main?id=2"
			})
			console.log("点击-新增")
		}
	},

}
</script>

<style lang="scss">
	#consignees{
		height: 100vh;
		.conList{
			width: 100%;
			height: 90vh;
			overflow: auto;
			ul{
				width: 100%;
				li{
					width: 90%;
					min-height: 70rpx;
					margin: 0 auto;
					padding: 30rpx 0;
					height: 100rpx;
					border-bottom: 1px solid rgb(179, 179, 179);
					.ipt {
						float: left;
						line-height: 100rpx;
						width: 10%;
					}
					.radioRight{
						width: 70%;
						float: left;
						margin-left: 20rpx;
						line-height: 50rpx;
						font-size: 30rpx;
						p{
							font-size: 28rpx;
							color: #7c7b7b;
							line-height: 32rpx;
						}
					}
					.bianji{
						float: right;
						
						width: 10%;
						.van-icon{
							font-size: 50rpx;
							line-height: 100rpx;
						}
					}
				}
			}
		}
		.addNew{
			width: 100%;
			position: fixed;
			bottom: 0;
			height: 100rpx;
			border: none;
			background: #1AAD19;
			color: #FFFFFF;
		}
		.button-hover{
			opacity: .8;
		}
	}

</style>

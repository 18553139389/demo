<template>
  <div id="accountInfo">
    <van-cell-group gutter="0">
      <van-cell center title="个人头像">
        <van-uploader>
          <div class="logo">
            <img src="../../../static/images/user.png" alt="">
          </div>
        </van-uploader>
      </van-cell>
      <!--<cell :title="$t('个人头像')" @click.native="photoClick" is-link>-->
      <!---->
      <!--</cell>-->
      <van-field label="姓" v-model="lastName" required clearable placeholder="请输入用户的姓"/>
      <van-field label="名" v-model="firstName" required clearable placeholder="请输入用户的名"/>
      <van-cell title="性别" is-link @click="shows" clickable="true"/>
      
    </van-cell-group>
    <button>保存</button>
    <van-popup v-model="show" position="bottom">
        1233
      </van-popup>
  </div>
</template>

<script>

export default {
  data(){
    return{
      show:true
    }
  },
  methods:{
    shows(){
      console.log(1111)
      this.show = true
    }
  }
}
</script>

<style lang='scss'>
  #accountInfo{
    height: 500px;
    width: 100%;
    .logo{
      width: 60px;
      height: 60px;
      border-radius: 50%;
      float: right;
      img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
      }
    }
    button{
      margin-top: 20px;
      width: 90%;
      height: 40px;
      background: #1AAD19;
      border-radius: 6px;
      margin: 20px auto;
      color: #fff;
      line-height: 40px;
      
    }
  }
  ._van-popup{
    height: 21px;
    width: 100%;
  }
</style>

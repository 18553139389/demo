<template>
  <div id="points">
     <div class="allNum">
       <div class="number">{{allNum}}</div>
       <div>总积分</div>
     </div>

     <div class="list">
        <div class="tips">
         <span>订单号:</span>
         <span>积分:</span>
         <span>订单生成时间:</span>
        </div>
        <scroll-view scroll-y>
          <div class="tipList">
            <ul>
              <li>
                <span>AP-151541733062</span>
                <span class="oneNum" ref="num">10.00</span>
                <span>2018-11-09 03:11:02</span>
              </li>
              <li>
                <span>AP-151541733062</span>
                <span class="oneNum" ref='num'>10.00</span>
                <span>2018-11-09 03:11:02</span>
              </li>
    
            </ul>
          </div>
        </scroll-view>
        
     </div>
  </div>
</template>

<script>

export default {
  data(){
    return{
      allNum: 20
    }
  },
  mounted:{
    
  }
}
</script>

<style lang='scss'>
  #points {
    height: 100vh;
    background: #FBF9FE;
    overflow: hidden;
    .allNum{
      width: 96%;
      margin: 5px auto;
      height: 110px;
      background: #F9D33D;
      color: #ffffff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      div{
        font-size: 24px;
        padding: 10px 20px;
      }
      .number{
        border-bottom: 1px solid #ffffff;
      }
    }
    .list {
      width: 100%;
      .tips{
        width: 100%;
        height: 35px;
        font-size: 16px;
        background: #F7F7F7;
        border-top: 1px solid #cccccc;
        border-bottom: 1px solid #cccccc;
        display: flex;
        align-items: center;
        justify-content: space-around;
      }
      .tipList {
        width: 100%;
        height: 80vh;
        background: #ffffff;
        ul {
          width: 100%;
          height: auto;
          li {
            display: flex;
            height: 35px;
            font-size: 14px;
            align-items: center;
            justify-content: space-around
          }
        }
      }
    }
  }
</style>

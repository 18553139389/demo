<template>
  <div class="orderBox">
    <van-tabs  v-if="allOrderHistory" id="orderHistory-tabs" sticky v-model="active" bind:change="onChange">
      <van-tab title="全部">
         <scroll-view
            scroll-y
          >
          <orderCard />
         </scroll-view>
      </van-tab>
      <van-tab title="待付款">内容 2</van-tab>
      <van-tab title="未发货">内容 3</van-tab>
      <van-tab title="已发货">内容 4</van-tab>
      <van-tab title="已完成">内容 5</van-tab>
    </van-tabs>
    <div class="no-order" v-else>
      <p>
        没有历史订单哦
      </p>
    </div>
  </div>
</template>

<script>
import orderCard from '@/components/order/orderCard.vue'
// import scroll from '@/components/bScroll'
export default {
  data () {
    return{
      active: 1,
      allOrderHistory: 122,
      showPayment: false,
    }
    
  },
  components:{
    orderCard
  },
  onChange(event) {
    wx.showToast({
      title: `切换到标签 ${event.detail.index + 1}`,
      icon: 'none'
    });
  },
  methods:{
  }
}

</script>

<style lang="scss">
  .orderBox {
    height: 100vh;
    overflow: hidden;
    background: #EEEEEE;
   .van-tabs__wrap--scrollable .van-tab {
      -webkit-flex:0 0 19%;
      flex:0 0 20%;
      .van-tabs__line{
        width: 30%;
      }
    }
    .van-tabs--line{
      overflow: auto;
    }
   // 无订单
    .no-order {
      height: 100vh;
      display: flex;

      text-align: center;
      p {
        margin: auto;
      }
    }
  }
  
</style>

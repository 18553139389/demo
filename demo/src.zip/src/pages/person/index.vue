

<template>
  <div class="container ">
    <!-- 头部 -->
    <div class="vipCard">
      <div class="usrInfo">
        <div class="userImg">
          <img src="../../../static/images/user.png" alt="">
          <h3>{{custName}}</h3>
        </div>
        <div class="userName"> {{account.mobile}}</div>
      </div>
    </div>

    <div class="userList">
      <van-cell-group class="user-group">
        <van-cell icon="records" title="全部订单" url="/pages/order/main" is-link />
        <van-cell icon="exchange" title="我的积分" url="/pages/points/main" is-link />
        <van-cell icon="gold-coin" title="优惠券" url="/pages/coupon/main" is-link />
        <van-cell icon="contact" title="我的信息" url="/pages/accountInfo/main" is-link />
        <van-cell icon="location" title="收货人信息" url="/pages/consignees/main" is-link />
        <van-cell icon="chat" title="版本号" :value="version"/>
        <van-cell icon="arrow-left" title="退出" @click="logout" />
      </van-cell-group>
      <div class="van-bottom"></div>
    </div>

  </div>
</template>

<script>
import personTop from '@/components/person/personTop.vue'
import personList from '@/components/person/personList.vue'
import Toast from '@/../static/vant/toast/toast'
export default {
  data() {
    return {
      custName: '',
      version: 1.12
    }
  },
  computed: {
    account () {
      let accountInfo = this.$store.getters['account/getAccountData']
      console.log(accountInfo,"获取用户名")
      this.custName = (accountInfo.lastName ? accountInfo.lastName : '') + accountInfo.firstName
      return accountInfo
    },
    isLogin () {
      return this.$store.getters['account/isLogin']
      console.log("走了-判断登录")
    }
  },
  methods: {
    logout () {
        this.$dialog.confirm({
          title: this.$t('确定退出?')
          // message: this.$t('确定退出?')
        }).then(() => {
          let self = this
          this.$store.dispatch('account/RESET').then(() => {
            self.alertDialog1Visible = false
            self.$router.replace({
              path: '/home'
            })
          })
        }).catch(() => {
          // on cancel
        })
      }
  },
}
</script>

<style lang='scss'>
 .usrInfo{
    width: 100%;
    height: 100%;
    background: #08080870;
    position: relative;
    color: #fff;
    .userImg{
      width: 100%;
      height: 120rpx;
      border-radius: 50%;
      img{
        width: 120rpx;
        height: 120rpx;
        border-radius: 50%;
        float: left;
      }
      h3{
        float: left;
        line-height: 120rpx;
        padding-left: 40rpx;
        font-weight: 500;
      }
    }
    .userName{
      position: absolute;
      bottom: 10rpx;
      font-size: 32rpx;
      text-indent: 10rpx;
    }
  }
	.vipCard{
    box-sizing: border-box;
    background: #d4abab;
    width: 100%;
    height: 420rpx;
    padding: 30rpx;
    background-image: url('../../../static/images/userbanner.png');
  }
</style>

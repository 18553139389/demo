<template>
  <div class="adress">
    <van-cell icon="shop-o" is-link url="/pages/consignees/main" class="jiantou">
      <view slot="title" class="slot">
        <div class="font"><van-icon name="contact" size="25px"/></div>
        <div class="person">联系人：<span>james</span></div>
        <div class="person">联系电话：<span>123456</span></div>
        <div class="person">地址：<span>CBD</span></div>
      </view>
    </van-cell>
    <div class="listItem">
         <van-card
            num="2"
            price="10.00"
            desc="(约合￥100.00)"
            title="商品标题0022220hjnhbg22"
            :thumb="imageURL"
            currency='AUD$'
            >
         </van-card>
      </div>   
      <van-cell
        title="配送方式"
        value="自提"
        is-link
      />
      <van-cell
        title="优惠券"
        value="使用优惠券"
        is-link
      />
      <van-cell-group>
        <van-field
          clearable
          label="发件人信息"
          icon="question-o"
          placeholder="请输入发件人信息（选填）"
          bind:click-icon="onClickIcon"
        />
        <van-field
          clearable
          label="发件人电话"
          placeholder="请输入发件人电话（选填）"
        />
        <van-field
          clearable
          label="留言"
          placeholder="选填(如需标记或其他特别需求请备注)"
        />
      </van-cell-group>
       <van-submit-bar
        :disabled="disabled"
        currency="AUD$"
        :price="100"
        button-text="结算"
        @submit="onSubmit"
      />
  </div>
</template>

<script>
export default {
  data () {
    return {
       imageURL: '../../../static/img/banner.png'
    }
  },
  methods: {
    
  }
}
</script>

<style lang="scss">
  .font{
    float:left;
    height:60px;
    margin-right: 30rpx;
    line-height: 60px;
    margin-top: 27rpx;
  }
  .jiantou .van-cell__right-icon-wrap{
     margin-top: 50rpx;
  }
    .listItem{
      width: 100%;
      .van-checkbox{
         display: flex;
         justify-content: space-between;
         align-items: center;
         .van-checkbox__icon{
               margin-left: 5rpx;
            }
      }
     ._van-card{
         width: 80%;
         .van-card__thumb{
            left: 0;
         }
         .van-card__title{
            font-size: 28rpx;
            font-weight: 600;
         }
         .van-card__price{
            font-size: 32rpx;
            color: #FF4444;
         }
         .van-card__desc{
            font-size: 24rpx;
            color: #688569;
         }
         .van-card__num{
            margin-top: 30rpx;
         }
         .van-card__price{
            position: relative;
         }
         .van-card__desc{
            position: absolute;
            right: 24rpx;
            top: 46rpx;
         }
      }
     
   }
</style>

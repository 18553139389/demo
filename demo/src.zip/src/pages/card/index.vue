<template>
  <div id="myCard">
		<!-- 循环列表 -->
    <div class="del" ><span>删除</span> </div>
    <div class="cList"  v-if="num > 0">
      <div class="listItem">
        <van-checkbox v-model="checked" @click="change" checked-color="#07c160">
         <van-card
            num="2"
            tag="热销"
            price="10.00"
            desc="(约合￥100.00)"
            title="商品标题0022220hjnhbg22"
            :thumb="imageURL"
            currency='AUD$'
            >
            <div slot="footer">
               <van-button size="mini" @click="popud" :show="show">编辑</van-button>
            </div>
         </van-card>
         </van-checkbox>
      </div>   
   </div>
    <div class="noOrder" v-else>
      <img src="../../../static/img/logobig.png" alt="">
      <p>您的购物车是空的</p>
    </div>
    <div class="bottom">
      <van-submit-bar
      :disabled="disabled"
      currency="AUD$"
      :price="100"
      button-text="提交订单"
      @submit="onSubmit"
    />
    <van-popup :show='show' @popud="popud" position="bottom" :overlay="false">
      <div class="popud">
        <img src="../../../static/img/banner.png" alt="">
        <div class="cont">
          <p>商品名称</p>
          <h2>AUD$ <span>100.00</span><span class="yuehe">(约合￥1000.00)</span></h2>
        </div>
        
      </div>
      <div class="buy"><span>我要买：</span><van-stepper v-model="value" step /></div>
      <van-button size="large" type="primary" @click="query">确认</van-button>
    </van-popup>
    </div>
  </div>
</template>

<script>
import mpCheckbox from 'mpvue-weui/src/checkbox';
export default {
  data() {
    return {
      num: 2,
      disabled: true,
      show: true,
      value: 1,
      checked: true,
      imageURL: '../../../static/img/banner.png'
    }
  },
  components:{
  },
  methods: {
    popud(){
      console.log(1222221)
      this.show=false
      
    },
    change() {
         if(this.checked){
            this.checked = false
         } else {
            this.checked = true
         }
    },
    query(){
      wx.navigateTo({
				url: "cardOrder/main?pid=1"
			})
    }
  }
}
</script>

<style lang='scss'>
#myCard{
  display: flex;
  flex-direction: column;
   .del{
    width: 100%;
    height: 60rpx;
    span{
      float: right;
      margin: 5rpx 10rpx;
      padding: 0 30rpx;
      font-size: 28rpx;
      border: 1px solid #FF4444;
      border-radius: 30rpx;
      color: #FF4444;
    }
    
  }
     .listItem{
      width: 100%;
      .van-checkbox{
         display: flex;
         justify-content: space-between;
         align-items: center;
         .van-checkbox__icon{
               margin-left: 5rpx;
            }
      }
     ._van-card{
         width: 80%;
         .van-card__thumb{
            left: 0;
         }
         .van-card__title{
            font-size: 28rpx;
            font-weight: 600;
         }
         .van-card__price{
            font-size: 32rpx;
            color: #FF4444;
         }
         .van-card__desc{
            font-size: 24rpx;
            color: #688569;
         }
         .van-card__num{
            margin-top: 30rpx;
         }
         .van-card__price{
            position: relative;
         }
         .van-card__desc{
            position: absolute;
            right: 24rpx;
            top: 46rpx;
         }
      }
     
   }
   
	.noOrder{
    height: 100vh;
    text-align: center;
    background: #ffffff;
    img{
      width: 50%;
      height: 320rpx;
      margin: 0 auto;
      margin-top: 200rpx;
    }
    p{
      font-size: 34rpx;
      color: #cccccc;
      margin-top: 50rpx;
    }

  }
  .van-popup{
    background: #f0f0f0;
     height: 380rpx;
    .popud{
      width: 100%;
      img{
        width: 160rpx;
        height: 160rpx;
        position: absolute;
        top: 0rpx;
        left: 15rpx;
      }
      .cont{
        margin-left: 200rpx;
        margin-top: 15rpx;
        p{
          font-size: 28rpx;
          line-height: 60rpx;
        }
        h2{
          font-size: 32rpx;
          color: #FF4444;
          .yuehe{
            color: #648561;
            font-size: 30rpx;
          }
        }
      }
    }
    .buy{
      margin-top: 55rpx;
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 100rpx;
      border-top: 1px solid #dddddd;
      span{
        font-size: 30rpx;
        text-indent: 20rpx;
      }
    }
  }
}
 
</style>

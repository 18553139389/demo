<template>
	<div>
		<img src="../../../static/images/new.png" style="height:300px; width:80%; margin-left:10%; margin-top:50px;"/>
		<div style="width:77%;ont-size:20px;margin:0 auto;text-align: center">
			客服微信号：API_666
		</div>
		<div style="text-align: center">
			请添加客服微信，将竭诚为您服务
		</div>
	</div>
</template>

<script>
	export default {
	}
</script>

<style>

</style>

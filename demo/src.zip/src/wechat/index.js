export default {
	changeUrl(url) {
		if(url == '/'){
			return '/pages/index/main'
		}
	}
}
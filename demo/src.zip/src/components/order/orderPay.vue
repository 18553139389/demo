<template>
  <div id="payment">
    <van-radio-group v-model="radio">
      <van-cell-group>
        <van-cell title="eWAY" clickable @click="radio = '1'">
          <van-radio name="1" checked-color="#07c160" />
        </van-cell>
        <van-cell title="微信支付" clickable @click="radio = '2'">
          <van-radio name="2" checked-color="#07c160" />
        </van-cell>
        <van-cell title="支付宝支付" clickable @click="radio = '3'">
          <van-radio name="3" checked-color="#07c160"/>
        </van-cell>
      </van-cell-group>
    </van-radio-group>
    <div class="pay-btn">
      <van-button size="large" type="primary" @click="goPay" >立即付款</van-button>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      list: ["eWAY", "微信支付", "支付宝支付"],
      radio: '1'
    };
  },
  methods:{
    onChange(event) {
      this.setData({
        result: event.detail
      });
    },
    toggle(event) {
      const { name } = event.currentTarget.dataset;
      checkbox.toggle();
    }
  }
};
</script>
